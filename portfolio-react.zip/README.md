Davis is the best minimal personal portfolio. This template has creative layout, supper smooth animation, unique features, modern and unique design which make your website more beautiful.

![01_preview __large_preview](https://github.com/codeplay-code/Davis-Personal-Portfolio-ReactJs-Template/assets/145067902/0db57385-7d6b-47e5-996e-54719e68c8ff)

https://github.com/codeplay-code/Davis-Personal-Portfolio-ReactJs-Template/wiki
